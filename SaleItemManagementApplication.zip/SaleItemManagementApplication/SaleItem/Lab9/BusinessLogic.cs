﻿//PROG1224
//Lab 9 Exercise
//Umar Kamalitdinov

using System;

namespace Lab9
{
    // Enumeration of Departments
    public enum Department
    {
        Default, Bakery, Deli, Grocery, Meat, Produce, Fish,
        Prepared, Clothing, Frozen, Bulk, Accessories, Garden
    }

    public class SaleItem
    {
        // Event Published
        public delegate void ZeroItem();
        public event ZeroItem CheckZeroItem;

        // Fields
        private string description;
        private decimal amount;

        // Properties
        public Department Department { get; set; }
        public string Description
        {
            get => this.description;
            set => this.description = value.Length > 0 ? value :
                throw new Exception("Item Description Required");
        }
        public decimal Amount 
        { 
            get => this.amount;
            set
            {
                this.amount = value;
                
                // Fire Event
                if (this.amount == 0M && CheckZeroItem != null)
                    CheckZeroItem();
            }
        }

        // Constructor
        public SaleItem(Department department, string description)
        {
            Department = department;
            Description = description;
        }

        // ToString
        public override string ToString()
            => $"{Department}: {Description}\n{Amount.ToString("C2")}";
    }
}
