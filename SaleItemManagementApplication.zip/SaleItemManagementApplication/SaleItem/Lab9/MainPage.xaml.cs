﻿//PROG1224
//Lab Exercise 9
//Umar Kamalitdinov

using System;
using System.Collections.Generic;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace Lab9
{
    public sealed partial class MainPage : Page
    {
        private List<SaleItem> saleItems = new List<SaleItem>();
        public MainPage()
        {
            this.InitializeComponent();

            // Display Departments
            foreach (Department d in Enum.GetValues(typeof(Department)))
                    this.cbDepartment.Items.Add(d);
        }

        private async void SubmitClick(object sender, RoutedEventArgs e)
        {
            // Obtain input
            decimal amount = 0M; 
            decimal.TryParse(txtAmount.Text, out amount);
            Department dept = Department.Default;
            if (cbDepartment.SelectedItem != null)
                dept = (Department)this.cbDepartment.SelectedItem;
            
            // Construct Sale Item
            try
            {
               
                SaleItem item = new SaleItem(dept, txtDescription.Text);
                // Register Custom Event
                item.CheckZeroItem += WarningMessage;
                item.Amount = amount;
                
                // Add to Collection and List View
                this.saleItems.Add(item);
                this.lstOutput.Items.Add(item.ToString());
            }
            catch (Exception ex)
            {
                // Display Exception for missing Description
                MessageDialog msg = new MessageDialog(ex.Message);
                await msg.ShowAsync();
            }
            finally
            {
                // Obtain and Display Total
                decimal total = 0M;
                foreach(SaleItem item in this.saleItems)
                    total += item.Amount;
                this.tbTotal.Text = total.ToString("C2");

                // Reset UI for Input
                this.cbDepartment.SelectedIndex = -1;
                this.txtAmount.Text = "";
                this.txtDescription.Text = "";
                this.cbDepartment.Focus(FocusState.Keyboard);
            }
        }

        // Custom Event
        public async void WarningMessage()
        {
            MessageDialog msg = new MessageDialog("Item Amount Zero","Warning");
            await msg.ShowAsync();
        }
    }
}
